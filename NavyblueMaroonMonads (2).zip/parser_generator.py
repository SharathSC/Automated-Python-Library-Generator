import re
import json
'''
Sample Output - 
def parse_show_vsx_status_config_sync(raw_result):
    """
    Parse the 'show vsx status config-sync' command raw output.

    :param str raw_result:vtysh raw result string.
    :rtype: dict
    :return: The parsed result of the show vsx sync status command in a \
            dictionary of the form:
    ::

      {
        'admin_state': 'Enabled',
        'operational_state': 'Operational',
        'error_state': 'None',
        'recommended remediation': 'N/A',
        'current_time': 'Fri Apr  6 02:31:46 2018',
        'last_sync_time': 'Not available'
      }
    """
    show_re = (
        r'Admin state\s*:\s*(?P<admin_state>\S+)?\s*'
        r'Operational State\s*:\s*(?P<operational_state>.*)?\s*'
        r'Error State\s*:\s*(?P<error_state>.*)?\s*'
        r'Recommended remediation\s*:\s*(?P<recommended_remediation>[\s\S]*)?\s*'  # noqa
        r'Current time\s*:\s*(?P<current_time>.*)?\s*'
        r'.*ast sync time\s*:\s*(?P<last_sync_time>.*)?\s*'
    )

    re_result = re_match(show_re, raw_result)
    assert re_result, 'The result was not able to be parsed.'
    result = re_result.groupdict()

    return result
'''


def parse_func_generator_colon(cli, data2):
    name = cli.replace(" ", "_")
    func_name = "def parse_" + name + "(raw_result):" + "\n"
    func_name = func_name + "    " + "'''" + "\n"
    func_name = func_name + "    " + "Parse the " + "'" + cli + "'" + " command raw output." + "\n"
    func_name = func_name + "    " + "\n"
    func_name = func_name + "    " + ":param str raw_result:vtysh raw result string." + "\n"
    func_name = func_name + "    " + ":rtype: dict" + "\n"
    func_name = func_name + "    " + ":return: The parsed result of the " + cli + " command in a \\" + "\n"
    func_name = func_name + "        " + "dictionary of the form:" + "\n"
    func_name = func_name + "    " + "::" + "\n"
    func_name = func_name + "    " + "\n"
    D = dict_creator_colon(data2)
    func_name = func_name + "    " + str(json.dumps(D, sort_keys=True, indent=6)) + "\n"
    func_name = func_name + "    " + "'''" + "\n"
    func_name = func_name + "    " + "show_re = (" + "\n"
    for k,v in D.items():
        func_name = func_name + "        " + "r'\s*" + k + "\s*:\s*(?P<" + k + ">.*)?\s*'" + "\n"
    func_name = func_name + "    " + ")" + "\n"
    func_name = func_name + "    " + "\n"
    func_name = func_name + "    " + "re_result = re_match(show_re, raw_result)" + "\n"
    func_name = func_name + "    " + "assert re_result, 'The result was not able to be parsed.'" + "\n"
    func_name = func_name + "    " + "result = re_result.groupdict()" + "\n"
    func_name = func_name + "    " + "\n"
    func_name = func_name + "    " + "return result" + "\n"
    return func_name


def dict_creator_colon(data):
    output = re.findall(r'(.*)\s:\s+(.*)\n', data)
    D = dict()
    for i in range(len(output)):
        l = output[i][0].lstrip()
        r = l.rstrip()
        D[r] = output[i][1]
    return D


