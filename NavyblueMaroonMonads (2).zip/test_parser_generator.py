import re
import json

'''
Sample Output - 
def test_parse_show_interface_loopback():
    raw_result = """
 Interface loopback2 is up
 Admin state is up
 Hardware: Loopback
 IPv4 address 10.0.0.1/24
     """

    result = parse_show_interface_loopback(raw_result)
    expected = {
        'lo2':
        {'AdminState': 'up',
         'ipv4_address': '10.0.0.1/24',
         'ipv6_address': None}
    }

    ddiff = DeepDiff(result, expected)
    assert not ddiff, 'The result is different than the expected'
'''


def parse_test_generator(cli, data2):
    name = cli.replace(" ", "_")
    func_name = "def test_parse_" + name + "():" + "\n"
    func_name = func_name + "    " + 'raw_result = """' + "\n"
    func_name = func_name + "    " + data2
    func_name = func_name + "    " + '"""' + "\n"
    func_name = func_name + "    " + "\n"
    func_name = func_name + "    " + "result = parse_" + name + "(raw_result)" + "\n"
    D = dict_creator(data2)
    func_name = func_name + "    " + "expected = " + str(json.dumps(D, sort_keys=True, indent=6)) + "\n"
    func_name = func_name + "    " + "\n"
    func_name = func_name + "    " + "ddiff = DeepDiff(result, expected)" + "\n"
    func_name = func_name + "    " + "assert not ddiff, 'The result is different than the expected'" + "\n"
    return func_name


def dict_creator(data):
    output = re.findall(r'(.*)\s:\s+(.*)\n', data)
    D = dict()
    for i in range(len(output)):
        l = output[i][0].lstrip()
        r = l.rstrip()
        D[r] = output[i][1]
    return D

