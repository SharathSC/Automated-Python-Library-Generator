{
	'command': 'class {Variable_0} {Variable_1} copy {Variable_2} ',
	'doc': ,
	'arguments': [
      {
        'name': 'Variable_0',
        'doc': ' ',
        'optional': False,
      },
      {
        'name': 'Variable_1',
        'doc': ' ',
        'optional': False,
      },
      {
        'name': 'Variable_2',
        'doc': ' ',
        'optional': False,
      },
  ],
}