def test_parse_show_vsx_status_config-sync():
    raw_result = """
    VSX Operational State    """
    
    result = parse_show_vsx_status_config-sync(raw_result)
    expected = {}
    
    ddiff = DeepDiff(result, expected)
    assert not ddiff, 'The result is different than the expected'
