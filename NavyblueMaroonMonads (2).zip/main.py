import re
import parser_generator
import test_parser_generator

def vtysh_meta_creator(cli_bare_cmdshare):
  vtysh_file = open('vtysh_meta_code.py','w')
  argument_list = re.findall(r"\{(\w\S+)\}", cli_bare_cmdshare)
  vtysh_file.write("{\n\
	\'command\': \'"+cli_bare_cmdshare+"\',\n\
	'doc': ,\n\
	'arguments': [\n")
  for count in range(0,len(argument_list)):
    vtysh_file.write("      {\n\
        \'name\': \'"+argument_list[count]+"',\n\
        \'doc\': \' \',\n\
        \'optional\': False,\n\
      },\n")
  vtysh_file.write("  ],\n}")
  vtysh_file.close()
  
def conf_func(func_name,cli_bare_cmdshare):
  g = open('testfunction.py','w')
  argument_list = re.findall(r"\{(\w\S+)\}", cli_bare_cmdshare)
  detail_arg = func_name.replace('_',' ')
  g.write("    def "+func_name+"(\n        self,\n        "+', '.join(argument_list)+",\n        dump_only=False,\n\
        config_outfile=None,\n\
        _shell='vtysh',\n\
        _shell_args=None\n    ):\n")
  g.write("\
        '''\n\
        "+detail_arg+".\n\n\
        This function runs the following vtysh command:\n\n\
        ::\n\
            # "+cli_bare_cmdshare+"\n\n\
        :param "+':\n        :param '.join(argument_list)+":\n\
        :param bool dump_only: if true, do not run the parser or exception checker\n\
        :param config_outfile: if file name is provided, config command will be written to file and not sent to switch console.\n\
        :param str _shell: shell to be selected\n\
        :param dict _shell_args: low-level shell API arguments\n\
        '''\n\
        ")
  g.write("shell_args = {\n\
            'matches': None,\n\
            'newline': True,\n\
            'timeout': None,\n\
            'connection': None\n\
        }\n\
        if _shell_args:\n\
            shell_args.update(_shell_args)\n\n\
        if not self._in_context:\n\
            raise VtyshException(\n\
                \""+func_name+"()\"\n\
                \" called outside of parent context\")")
  g.write("\n        cmd = [\n\
            \'"+cli_bare_cmdshare+"\'\n\
        ]\n\n")
  g.write("        _prompt_response = None\n\n\
        cmd = ((' '.join(cmd)).format(**locals()))\n\n\
        if self.config_outfile:\n\
            dump_only = True\n\
            if self.large_config == 'start':\n\
                self.enode.run_cfg_str = (\n\
                    self.enode.run_cfg_str + \"    \" + cmd + \'\\n\')\n\
            elif self.large_config == 'end':\n\
                if self.enode.run_cfg_str != \'\':\n\
                    self.enode.run_cfg_str = \'\'\n\
                _send_command_to_file(\"    \" + cmd + \'\\n\', self.config_outfile)\n")
  g.write("        else:\n\
            result = _send_command(\n\
                self.enode, cmd, _shell, shell_args,\n\
                _prompt_response=_prompt_response)\n\
        if not dump_only:\n\
            if result:\n\
                raise determine_exception(result)(result)")
  g.close()   


def show_func(func_name,cli_bare_cmdshare):
  h = open('showfunction.py','w')
  argument_list = re.findall(r"\{(\w\S+)\}", cli_bare_cmdshare)
  detail_arg = func_name.replace('_',' ')
  cli_bare_cmdshare = cli_bare_cmdshare.strip()
  lenimp = len(cli_bare_cmdshare)
  count = len(argument_list)
  if count is not 0:
    h.write("def "+func_name+"(\n    enode,\n    "+', '.join(argument_list)+",\n    dump_only=False,\n\
    _shell='vtysh',\n    _shell_args=None\n):\n")
    h.write("    '''\n    "+detail_arg+".\n\n    This function runs the following vtysh command:\n\n    ::\n    # "+cli_bare_cmdshare+"\n\n    :param dict kwargs: arguments to pass to the send_command of the\n\
     vtysh shell.\n    :param "+':\n    :param '.join(argument_list)+":\n    :param bool dump_only: if true, do not run the parser or exception checker\n    :param str _shell: shell to be selected\n    :param dict _shell_args: low-level shell API arguments\n    :return: A dictionary as returned by\n     :func:`topology_lib_vtysh.parser.parse_show_"+func_name+"`\n    '''\n")
    h.write("    shell_args = {\n        'matches': None,\n        'newline': True,\n        'timeout': None,\n        'connection': None\n    }\n\
    if _shell_args:\n\
        shell_args.update(_shell_args)\n\n")
    h.write("\n    cmd = [\n\
        \'"+cli_bare_cmdshare+"\'\n\
    ]\n\n")
    check = cli_bare_cmdshare.split(' ')
    for item in argument_list:
      if item in check[2]:
        print("It is reaching this loop "+check[2])
        h.write("    port = _get_port(enode, "+argument_list[0]+")\n")
      else:
        print(check[2])
        h.write("    if "+''.join(argument_list)+" and \'{"+argument_list[0]+"}\' not in cmd[0]:\n\
        cmd.append(\n\
            \'{}{{"+''.join(argument_list)+"}}{}\'.format(\n\
                '', ''\n\
            )\n\
        )")
    h.write("\n\n    _prompt_response = None\n\n\
    cmd = ((' '.join(cmd)).format(**locals()))\n\n\
    result = _send_command(\n\
        enode, cmd, _shell, shell_args, _prompt_response=_prompt_response)\n\n\
    if not dump_only:\n\
        return run_parser(parse_"+func_name+", result)  # noqa\n\
    else:\n\
        return result\n")
    h.close()
  else:
    h.write("def "+func_name+"(\n    enode,\n    dump_only=False,\n    _shell='vtysh',\n\
    _shell_args=None\n):\n")
    h.write("\
    '''\n\
    "+detail_arg+"\n\n\
    This function runs the following VTYSH command:\n\n\
    ::\n\
        # "+cli_bare_cmdshare.strip()+"\n\n\
    :param dict kwargs: arguments to pass to the send_command of the\n\
     vtysh shell.\n\
    :param bool dump_only: if true, do not run the parser or exception checker\n\
    :param str _shell: shell to be selected\n\
    :param dict _shell_args: low-level shell API arguments\n\
    :return: A dictionary as returned by\n\
     :func:`topology_lib_vtysh.parser.parse_"+func_name+"`\n\
    '''\n\
    ")
    h.write("shell_args = {\n\
        'matches': None,\n\
        'newline': True,\n\
        'timeout': None,\n\
        'connection': None\n\
    }\n\
    if _shell_args:\n\
        shell_args.update(_shell_args)\n\n")
    h.write("\n    cmd = [\n\
        \'"+cli_bare_cmdshare+"\'\n\
    ]\n\n")
    h.write("    _prompt_response = None\n\n\
    cmd = ((' '.join(cmd)).format(**locals()))\n\n\
    result = _send_command(\n\
        enode, cmd, _shell, shell_args, _prompt_response=_prompt_response)\n\n\
    if not dump_only:\n\
        return run_parser(parse_"+func_name+", result)  # noqa\n\
    else:\n\
        return result\n")
    h.close()

cli_bare = ''
cli_bare_cmdshare = ''
complete_CLI = input('Enter the complete CLI\n')
complete_CLI = complete_CLI.strip()
variables_in_CLI = input('Enter the Variables in CLI seperated by comma')
data = input('Enter the Output Response for the given CLI')
variables_in_CLI = variables_in_CLI.strip()
variables_list = variables_in_CLI.split(',')
cli_split = complete_CLI.split(' ')
for item in variables_list:
  if item not in complete_CLI:
    assert False, 'CLI Variables Wrong'
count = 0
print(cli_split)
for item in cli_split:
  if item not in variables_list:
    cli_bare = cli_bare + item + ' '
    cli_bare_cmdshare = cli_bare_cmdshare + item + ' '
  else:
    cli_bare_cmdshare = cli_bare_cmdshare + '{Variable_'+ str(count) +'} '
    count = count + 1
cli_bare = cli_bare.strip()
print('Complete CLI is '+complete_CLI)
print('CLI without Variables are '+cli_bare)
func_name = cli_bare.replace(' ','_')
#print('Function name is '+func_name)
if complete_CLI.startswith('show'):
  func_name = func_name.replace('-','_')
  show_func(func_name,cli_bare_cmdshare)
  return_func_value = parser_generator.parse_func_generator_colon(complete_CLI,data)
  return_test_value = test_parser_generator.parse_test_generator(complete_CLI,data)
  f = open('ParseFunc.py','w')
  f.write(return_func_value)
  f.close()
  g = open('return_test_value.py','w')
  g.write(return_test_value)
  g.close()
else:
  vtysh_meta_creator(cli_bare_cmdshare)
  conf_func(func_name,cli_bare_cmdshare)