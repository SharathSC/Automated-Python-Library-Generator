def parse_show_vsx_status_config-sync(raw_result):
    '''
    Parse the 'show vsx status config-sync' command raw output.
    
    :param str raw_result:vtysh raw result string.
    :rtype: dict
    :return: The parsed result of the show vsx status config-sync command in a \
        dictionary of the form:
    ::
    
    {}
    '''
    show_re = (
    )
    
    re_result = re_match(show_re, raw_result)
    assert re_result, 'The result was not able to be parsed.'
    result = re_result.groupdict()
    
    return result
