    def class_copy(
        self,
        Variable_0, Variable_1, Variable_2,
        dump_only=False,
        config_outfile=None,
        _shell='vtysh',
        _shell_args=None
    ):
        '''
        class copy.

        This function runs the following vtysh command:

        ::
            # class {Variable_0} {Variable_1} copy {Variable_2} 

        :param Variable_0:
        :param Variable_1:
        :param Variable_2:
        :param bool dump_only: if true, do not run the parser or exception checker
        :param config_outfile: if file name is provided, config command will be written to file and not sent to switch console.
        :param str _shell: shell to be selected
        :param dict _shell_args: low-level shell API arguments
        '''
        shell_args = {
            'matches': None,
            'newline': True,
            'timeout': None,
            'connection': None
        }
        if _shell_args:
            shell_args.update(_shell_args)

        if not self._in_context:
            raise VtyshException(
                "class_copy()"
                " called outside of parent context")
        cmd = [
            'class {Variable_0} {Variable_1} copy {Variable_2} '
        ]

        _prompt_response = None

        cmd = ((' '.join(cmd)).format(**locals()))

        if self.config_outfile:
            dump_only = True
            if self.large_config == 'start':
                self.enode.run_cfg_str = (
                    self.enode.run_cfg_str + "    " + cmd + '\n')
            elif self.large_config == 'end':
                if self.enode.run_cfg_str != '':
                    self.enode.run_cfg_str = ''
                _send_command_to_file("    " + cmd + '\n', self.config_outfile)
        else:
            result = _send_command(
                self.enode, cmd, _shell, shell_args,
                _prompt_response=_prompt_response)
        if not dump_only:
            if result:
                raise determine_exception(result)(result)